# MusicPlayerOfficial

A journey of programming to explore the technology behind a music application to Android Platform.

This is just a prototype.
