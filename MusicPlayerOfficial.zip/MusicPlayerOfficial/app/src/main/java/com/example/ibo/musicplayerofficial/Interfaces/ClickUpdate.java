package com.example.ibo.musicplayerofficial.Interfaces;

public interface ClickUpdate {
    void getClicks(int position);
}
