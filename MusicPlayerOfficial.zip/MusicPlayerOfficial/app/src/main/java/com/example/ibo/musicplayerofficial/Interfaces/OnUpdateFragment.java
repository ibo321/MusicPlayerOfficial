package com.example.ibo.musicplayerofficial.Interfaces;

public interface OnUpdateFragment {
    void onDataSetChanged();
}
